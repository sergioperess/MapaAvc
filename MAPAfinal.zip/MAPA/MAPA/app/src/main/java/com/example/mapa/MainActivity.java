import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import java.util.concurrent.ArrayBlockingQueue;

public class Main extends AppCompatActivity implements OnMapReadyCallback {

    private LocationManagerService locationManagerService;
    private RegionManager regionManager;
    private MapManager mapManager;
    private RegionQueueManager regionQueueManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationManagerService = new LocationManagerService(this);
        locationManagerService.startLocationUpdates();

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        GoogleMap mMap = null;
        mapManager = new MapManager(mMap);

        ArrayBlockingQueue<LatLng> regionQueue = new ArrayBlockingQueue<>(10);
        regionManager = new RegionManager(regionQueue);

        regionQueueManager = new RegionQueueManager(regionQueue);
        regionQueueManager.processRegionQueue();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == ActivityCompat.PERMISSION_GRANTED) {
            locationManagerService.startLocationUpdates();
        }
    }
}

